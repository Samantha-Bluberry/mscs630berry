package tests;

import aesproject.AESCipher;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertEquals;

public class EncryptionTests {
  @Test
  void test_Strings1(){
    String input = "When an escape sequence is encountered in a print statement, \nA new line is written.";

    String[] output = AESCipher.stringToHex(input);
    String output2 = AESCipher.hexToString(output);

    System.out.print("Expected: " + input+ "\n");
    System.out.print("Got:      " + output2 + "\n\n");

    assertEquals(input, output2);
  }

  @Test
  void test_Strings2(){
    String input = "Hello World! :)";

    String[] output = AESCipher.stringToHex(input);
    String output2 = AESCipher.hexToString(output);

    System.out.print("Expected: " + input+ "\n");
    System.out.print("Got:      " + output2 + "\n\n");

    assertEquals(input, output2);
  }

  @Test
  void ende_test1(){
    String key = "1FEBB03C5E21759126707EF3BEFC06B4";
    String input = "A98FFF752FBF546DCF582A9E97044713";

    String inVector = "29C3505F571420F6402299B31A02D73A";
    AESCipher driverAES = new AESCipher();
    String output1 = driverAES.AES("29C3505F571420F6402299B31A02D73A", key, inVector);
    inVector = output1;
    String output2 = driverAES.AES(input,key,inVector);

    inVector = "29C3505F571420F6402299B31A02D73A";
    String tomm = output1;
    String tem = driverAES.decryption(output1,key,inVector);
    inVector = tomm;
    output2 = driverAES.decryption(output2,key,inVector);

    System.out.print("Expected: " + input+ "\n");
    System.out.print("Got:      " + output2 + "\n\n");

    assertEquals(input, output2);
  }

  @Test
  void ende_test2(){
    String key = "82C555ECD26FBA14399F994188A51638";
    String input = "366839AE6597721D033955D7AA2613C7";

    String inVector = "29C3505F571420F6402299B31A02D73A";
    AESCipher driverAES = new AESCipher();
    String output1 = driverAES.AES("29C3505F571420F6402299B31A02D73A", key, inVector);
    inVector = output1;
    String output2 = driverAES.AES(input,key,inVector);

    inVector = "29C3505F571420F6402299B31A02D73A";
    String tomm = output1;
    String tem = driverAES.decryption(output1,key,inVector);
    inVector = tomm;
    output2 = driverAES.decryption(output2,key,inVector);

    System.out.print("Expected: " + input+ "\n");
    System.out.print("Got:      " + output2 + "\n\n");

    assertEquals(input, output2);
  }

  @Test
  void all_together_test(){
    AESCipher driver5 = new AESCipher();
    String key = "7E19DFF11852D7D90BAAC6274BC18A71";
    String input = "Hellow World!\nFrom Sam";

    String[] inputHex = AESCipher.stringToHex(input);
    String[] outputHex = new String[inputHex.length+1];
    //String inVector = AESCipher.genHexString(16);
    String inVector = "7E19DFF11852D7D90BAAC6274BC18A71";

    outputHex[0] = driver5.AES(AESCipher.genHexString(16),key,inVector);
    inVector = outputHex[0];

    for (int i = 0; i < inputHex.length;i++){
      outputHex[i+1] = driver5.AES(inputHex[i],key,inVector);
      inVector = outputHex[i+1];
    }

    System.out.println(AESCipher.hexToString(outputHex));

    inVector = AESCipher.genHexString(16);

    for (int i = 0; i < outputHex.length;i++) {
      String temp = outputHex[i];
      outputHex[i] = driver5.decryption(outputHex[i], key, inVector);
      inVector = temp;
    }


    String finalOut = AESCipher.hexToString(outputHex);

    finalOut = finalOut.substring(16);

    System.out.print("Expected: " + input+ "\n");
    System.out.print("Got:      " + finalOut + "\n\n");

    assertEquals(input,finalOut);
  }
}
